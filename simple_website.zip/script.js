function showMessage() {
    alert("شكرًا لزيارتك! أتمنى أن يعجبك الموقع 😊");
}
